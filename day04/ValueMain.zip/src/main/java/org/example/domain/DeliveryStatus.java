package org.example.domain;

public enum DeliveryStatus {

}

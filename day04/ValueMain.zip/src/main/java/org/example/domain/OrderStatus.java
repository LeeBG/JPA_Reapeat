package org.example.domain;

public enum OrderStatus {
    ORDER, CANCLE
}

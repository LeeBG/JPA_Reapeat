package org.example;

import org.example.domain.*;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import java.util.List;

public class JpaMain {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");

        EntityManager em = emf.createEntityManager();

        EntityTransaction tx = em.getTransaction();

        tx.begin();


        try {

            // Embeded 타입을 공유하면 위험하다 못잡는 버그가 발생할 수 있다.
            Member member = new Member();
            member.setUsername("member1");
            member.setHomeAddress(new Address("city", "street", "10000"));
            member.getFavoriteFoods().add("치킨");
            member.getFavoriteFoods().add("족발");
            member.getFavoriteFoods().add("피자");

            member.getAddressHistory().add(new AddressEntity("old1","street","10000"));
            member.getAddressHistory().add(new AddressEntity("old2","street","10000"));

            em.persist(member);

            em.flush();
            em.clear();


            System.out.println("===========start========");

            Member findMember = em.find(Member.class, member.getId());

            // 값타입이라는 것은 immutable 불변성을 가져야한다.
//            findMember.getHomeAddress().setCity("newCity");

            // 값 타입은 새로 넣어야한다.
            Address a = findMember.getHomeAddress();
            findMember.setHomeAddress(new Address("newCity",a.getStreet(),a.getZipCode()));

            // 치킨 -> 한식
            findMember.getFavoriteFoods().remove("치킨");
            findMember.getFavoriteFoods().add("한식");

            findMember.getAddressHistory().remove(new AddressEntity("old1","street","10000"));
            findMember.getAddressHistory().add(new AddressEntity("newCity1","street","10000"));


            tx.commit();
        } catch (Exception e) {
            System.err.println("ㅈ버그 발견!!!" + e.getMessage());
            tx.rollback();
        } finally {
            em.close();
        }
        emf.close();
    }

    private static void logic(Member m1, Member m2) {
        System.out.println("m1 == m2 >> " + (m1 instanceof Member));
        System.out.println("m1 == m2 >> " + (m2 instanceof Member));
    }
}
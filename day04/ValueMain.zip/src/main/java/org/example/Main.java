package org.example;

public class Main {
//    public static void main(String[] args) {
//        // int, double 같은 기본타입(primitive type)은 공유가 불가능하다.
//
//        // 래퍼클래스나 String같은 특수한 클래스는 공유가 가능하다.
//
//        Integer a = new Integer(10);
//        Integer b = a;
//
////        a.setValue(20);
//
//        System.out.println("a = " + a);
//        System.out.println("b = " + b);
//
//        // 임베디드 타입(복합 값 타입)
//        /*
//         * 1. 새로운 값 타입을 직접 정의할 수 있음
//         * 2. JPA는 임베디드 타입(embedded type)이라 함
//         * 3. 주로 기본 값 타입을 모아서 만들어서 복합 값 타입이라고 한다.
//         * 4. int, String 같은 값 타입이라는 것이다. 엔티티가 아니라.
//         */
//
//
//    }
}